# change-all-UI-fonts
Chrome extension that replaces all UI font to a user-given font.

https://chrome.google.com/webstore/detail/change-all-ui-fonts/loiejdbcheeiipmakhghinclmpafiiel?utm_source=chrome-ntp-icon
